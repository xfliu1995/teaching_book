knitr::opts_chunk$set(cache = T) 
knitr::opts_chunk$set(dev = 'png')
knitr::opts_chunk$set(fig.height = 7, fig.width = 7) # pdf default are 7
